<?php
   // Start the session
?>
<!DOCTYPE html>
<html>
   <body>
      <?php
         // remove previous session variable
         // Set session variables
         // echo that variables have been set
?>
      <a href="thursdaySession2.php">Check the variables on another page</a>

      <?php // set session variables using a form ?>
   </body>
</html>