<h3>Display all cookies</h3>
<?php // code to display all cookies ?>
<h1><?php // use the single cookie ?></h1>
