<?php 
   // start session
   // save session variables into local variables
?>
<h1><?php // use the session variables ?></h1>
<?php ?>